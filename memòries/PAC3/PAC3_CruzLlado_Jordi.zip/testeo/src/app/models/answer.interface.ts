export interface Answer {
  id: number;
  text: string;
  correct: boolean;
}