export interface TestForm {
  title: string;
  description: string;
  successScore?: number;
  errorScore?: number;
  favorite?: boolean;
}